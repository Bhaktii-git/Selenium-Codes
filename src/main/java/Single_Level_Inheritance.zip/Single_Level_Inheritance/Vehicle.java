package Single_Level_Inheritance;

public class Vehicle {

	//String brand;
	//int speed;
	
	
	public void  displayDerails(String brand,int speed)
	{
		System.out.println("Vehicle Brand :"+brand);
		
		System.out.println("Maximum speed  :"+speed+ "Km/hr");
	}
}
