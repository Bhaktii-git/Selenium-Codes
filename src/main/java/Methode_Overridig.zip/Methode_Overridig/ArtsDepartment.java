package Methode_Overridig;

public class ArtsDepartment extends College
{

	public void showDepartmentDetails() 
	{
		System.out.println("Arts Department offers courses in Literature, History, and Political Science.");
	}
	
	
}
