package Methode_Overridig;

public class MedicalDepartment extends College
{

	public void showDepartmentDetails() 
	{
		System.out.println("Medical Department trains students in fields like MBBS, Nursing, and Pharmacy.");
	}
	
	
}
