package Methode_Overridig;

public class CutomerCare extends College
{
	
	public void contactSupport() 
	{
		System.out.println("If you are unsure which department to choose, please contact our support team at: 1800-123-456");

}
	
}
