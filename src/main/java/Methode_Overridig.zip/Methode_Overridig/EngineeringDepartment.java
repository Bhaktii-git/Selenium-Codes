package Methode_Overridig;

public class EngineeringDepartment extends College
{
	
	
	public void showDepartmentDetails() 
	{
		System.out.println("Engineering Department focuses on technical education like Computer Science, Civil, and Mechanical Englheering.");
	}


}
