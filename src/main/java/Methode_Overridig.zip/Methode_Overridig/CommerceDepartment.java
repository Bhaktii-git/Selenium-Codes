package Methode_Overridig;

public class CommerceDepartment extends College
{

	public void showDepartmentDetails() 
	{
		System.out.println("Commerce Department covers Accounting, Business Studies, and Economics");
	}
	
	
	
}
