package Libaray_Demo;

public class Book 
{
   String tittle1;
   String author1;
   double price1;
   
  

   public Book(String tittle1, String author1, double price1) 
{
		this.tittle1=tittle1;
		   this.author1=author1;
		   this.price1=price1;
}
}
